This QNX skin package was created entirely from screenshots from my
install of QNX_RTP. The original graphics were created by William
Bull of QNX Software Systems.

Author:
Craig Erskine

Email:
craig@solardreamstudios.com

Website:
www.solardreamstudios.com
skins.solardreamstudios.com