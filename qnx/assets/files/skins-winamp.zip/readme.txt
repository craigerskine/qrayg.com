This QNX skin package was created entirely from screenshots from my
install of QNX_RTP. The original graphics were created by William
Bull of QNX Software Systems.

Author:
qrayg

Email:
qrayg@qrayg.com

Website:
qrayg.com